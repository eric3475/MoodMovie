/**
 * This class contains generated code from the Codename One Designer, DO NOT MODIFY!
 * This class is designed for subclassing that way the code generator can overwrite it
 * anytime without erasing your changes which should exist in a subclass!
 * For details about this file and how it works please read this blog post:
 * http://codenameone.blogspot.com/2010/10/ui-builder-class-how-to-actually-use.html
*/
package generated;

import com.codename1.ui.*;
import com.codename1.ui.util.*;
import com.codename1.ui.plaf.*;
import java.util.Hashtable;
import com.codename1.ui.events.*;

public abstract class StateMachineBase extends UIBuilder {
    private Container aboutToShowThisContainer;
    /**
     * this method should be used to initialize variables instead of
     * the constructor/class scope to avoid race conditions
     */
    /**
    * @deprecated use the version that accepts a resource as an argument instead
    
**/
    protected void initVars() {}

    protected void initVars(Resources res) {}

    public StateMachineBase(Resources res, String resPath, boolean loadTheme) {
        startApp(res, resPath, loadTheme);
    }

    public Container startApp(Resources res, String resPath, boolean loadTheme) {
        initVars();
        UIBuilder.registerCustomComponent("Container", com.codename1.ui.Container.class);
        UIBuilder.registerCustomComponent("WebBrowser", com.codename1.components.WebBrowser.class);
        UIBuilder.registerCustomComponent("Form", com.codename1.ui.Form.class);
        UIBuilder.registerCustomComponent("Button", com.codename1.ui.Button.class);
        UIBuilder.registerCustomComponent("TextArea", com.codename1.ui.TextArea.class);
        UIBuilder.registerCustomComponent("Label", com.codename1.ui.Label.class);
        UIBuilder.registerCustomComponent("TextField", com.codename1.ui.TextField.class);
        UIBuilder.registerCustomComponent("MultiList", com.codename1.ui.list.MultiList.class);
        UIBuilder.registerCustomComponent("SpanLabel", com.codename1.components.SpanLabel.class);
        if(loadTheme) {
            if(res == null) {
                try {
                    if(resPath.endsWith(".res")) {
                        res = Resources.open(resPath);
                        System.out.println("Warning: you should construct the state machine without the .res extension to allow theme overlays");
                    } else {
                        res = Resources.openLayered(resPath);
                    }
                } catch(java.io.IOException err) { err.printStackTrace(); }
            }
            initTheme(res);
        }
        if(res != null) {
            setResourceFilePath(resPath);
            setResourceFile(res);
            initVars(res);
            return showForm(getFirstFormName(), null);
        } else {
            Form f = (Form)createContainer(resPath, getFirstFormName());
            initVars(fetchResourceFile());
            beforeShow(f);
            f.show();
            postShow(f);
            return f;
        }
    }

    protected String getFirstFormName() {
        return "Main";
    }

    public Container createWidget(Resources res, String resPath, boolean loadTheme) {
        initVars();
        UIBuilder.registerCustomComponent("Container", com.codename1.ui.Container.class);
        UIBuilder.registerCustomComponent("WebBrowser", com.codename1.components.WebBrowser.class);
        UIBuilder.registerCustomComponent("Form", com.codename1.ui.Form.class);
        UIBuilder.registerCustomComponent("Button", com.codename1.ui.Button.class);
        UIBuilder.registerCustomComponent("TextArea", com.codename1.ui.TextArea.class);
        UIBuilder.registerCustomComponent("Label", com.codename1.ui.Label.class);
        UIBuilder.registerCustomComponent("TextField", com.codename1.ui.TextField.class);
        UIBuilder.registerCustomComponent("MultiList", com.codename1.ui.list.MultiList.class);
        UIBuilder.registerCustomComponent("SpanLabel", com.codename1.components.SpanLabel.class);
        if(loadTheme) {
            if(res == null) {
                try {
                    res = Resources.openLayered(resPath);
                } catch(java.io.IOException err) { err.printStackTrace(); }
            }
            initTheme(res);
        }
        return createContainer(resPath, "Main");
    }

    protected void initTheme(Resources res) {
            String[] themes = res.getThemeResourceNames();
            if(themes != null && themes.length > 0) {
                UIManager.getInstance().setThemeProps(res.getTheme(themes[0]));
            }
    }

    public StateMachineBase() {
    }

    public StateMachineBase(String resPath) {
        this(null, resPath, true);
    }

    public StateMachineBase(Resources res) {
        this(res, null, true);
    }

    public StateMachineBase(String resPath, boolean loadTheme) {
        this(null, resPath, loadTheme);
    }

    public StateMachineBase(Resources res, boolean loadTheme) {
        this(res, null, loadTheme);
    }

    public com.codename1.ui.Button findTrailerButton(Component root) {
        return (com.codename1.ui.Button)findByName("trailerButton", root);
    }

    public com.codename1.ui.Button findTrailerButton() {
        com.codename1.ui.Button cmp = (com.codename1.ui.Button)findByName("trailerButton", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Button)findByName("trailerButton", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Container findContainer3(Component root) {
        return (com.codename1.ui.Container)findByName("Container3", root);
    }

    public com.codename1.ui.Container findContainer3() {
        com.codename1.ui.Container cmp = (com.codename1.ui.Container)findByName("Container3", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Container)findByName("Container3", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Label findLabel(Component root) {
        return (com.codename1.ui.Label)findByName("Label", root);
    }

    public com.codename1.ui.Label findLabel() {
        com.codename1.ui.Label cmp = (com.codename1.ui.Label)findByName("Label", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Label)findByName("Label", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.list.MultiList findNewsMultiList(Component root) {
        return (com.codename1.ui.list.MultiList)findByName("NewsMultiList", root);
    }

    public com.codename1.ui.list.MultiList findNewsMultiList() {
        com.codename1.ui.list.MultiList cmp = (com.codename1.ui.list.MultiList)findByName("NewsMultiList", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.list.MultiList)findByName("NewsMultiList", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Container findContainer4(Component root) {
        return (com.codename1.ui.Container)findByName("Container4", root);
    }

    public com.codename1.ui.Container findContainer4() {
        com.codename1.ui.Container cmp = (com.codename1.ui.Container)findByName("Container4", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Container)findByName("Container4", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Container findContainer1(Component root) {
        return (com.codename1.ui.Container)findByName("Container1", root);
    }

    public com.codename1.ui.Container findContainer1() {
        com.codename1.ui.Container cmp = (com.codename1.ui.Container)findByName("Container1", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Container)findByName("Container1", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Container findContainer2(Component root) {
        return (com.codename1.ui.Container)findByName("Container2", root);
    }

    public com.codename1.ui.Container findContainer2() {
        com.codename1.ui.Container cmp = (com.codename1.ui.Container)findByName("Container2", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Container)findByName("Container2", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Container findContainer5(Component root) {
        return (com.codename1.ui.Container)findByName("Container5", root);
    }

    public com.codename1.ui.Container findContainer5() {
        com.codename1.ui.Container cmp = (com.codename1.ui.Container)findByName("Container5", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Container)findByName("Container5", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Container findContainerCenter(Component root) {
        return (com.codename1.ui.Container)findByName("ContainerCenter", root);
    }

    public com.codename1.ui.Container findContainerCenter() {
        com.codename1.ui.Container cmp = (com.codename1.ui.Container)findByName("ContainerCenter", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Container)findByName("ContainerCenter", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Container findContainer(Component root) {
        return (com.codename1.ui.Container)findByName("Container", root);
    }

    public com.codename1.ui.Container findContainer() {
        com.codename1.ui.Container cmp = (com.codename1.ui.Container)findByName("Container", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Container)findByName("Container", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Button findBeginButton(Component root) {
        return (com.codename1.ui.Button)findByName("BeginButton", root);
    }

    public com.codename1.ui.Button findBeginButton() {
        com.codename1.ui.Button cmp = (com.codename1.ui.Button)findByName("BeginButton", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Button)findByName("BeginButton", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.components.SpanLabel findResultSpanLabel(Component root) {
        return (com.codename1.components.SpanLabel)findByName("ResultSpanLabel", root);
    }

    public com.codename1.components.SpanLabel findResultSpanLabel() {
        com.codename1.components.SpanLabel cmp = (com.codename1.components.SpanLabel)findByName("ResultSpanLabel", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.components.SpanLabel)findByName("ResultSpanLabel", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Label findFalseLabel(Component root) {
        return (com.codename1.ui.Label)findByName("FalseLabel", root);
    }

    public com.codename1.ui.Label findFalseLabel() {
        com.codename1.ui.Label cmp = (com.codename1.ui.Label)findByName("FalseLabel", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Label)findByName("FalseLabel", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Button findButton(Component root) {
        return (com.codename1.ui.Button)findByName("Button", root);
    }

    public com.codename1.ui.Button findButton() {
        com.codename1.ui.Button cmp = (com.codename1.ui.Button)findByName("Button", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Button)findByName("Button", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Button findQuestionsButton(Component root) {
        return (com.codename1.ui.Button)findByName("QuestionsButton", root);
    }

    public com.codename1.ui.Button findQuestionsButton() {
        com.codename1.ui.Button cmp = (com.codename1.ui.Button)findByName("QuestionsButton", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Button)findByName("QuestionsButton", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.TextField findSubjectTextField(Component root) {
        return (com.codename1.ui.TextField)findByName("SubjectTextField", root);
    }

    public com.codename1.ui.TextField findSubjectTextField() {
        com.codename1.ui.TextField cmp = (com.codename1.ui.TextField)findByName("SubjectTextField", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.TextField)findByName("SubjectTextField", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Label findTitleSecondNewsLabel(Component root) {
        return (com.codename1.ui.Label)findByName("TitleSecondNewsLabel", root);
    }

    public com.codename1.ui.Label findTitleSecondNewsLabel() {
        com.codename1.ui.Label cmp = (com.codename1.ui.Label)findByName("TitleSecondNewsLabel", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Label)findByName("TitleSecondNewsLabel", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Label findMainImageLabel(Component root) {
        return (com.codename1.ui.Label)findByName("MainImageLabel", root);
    }

    public com.codename1.ui.Label findMainImageLabel() {
        com.codename1.ui.Label cmp = (com.codename1.ui.Label)findByName("MainImageLabel", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Label)findByName("MainImageLabel", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.components.SpanLabel findMovieDescriptionLabel(Component root) {
        return (com.codename1.components.SpanLabel)findByName("movieDescriptionLabel", root);
    }

    public com.codename1.components.SpanLabel findMovieDescriptionLabel() {
        com.codename1.components.SpanLabel cmp = (com.codename1.components.SpanLabel)findByName("movieDescriptionLabel", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.components.SpanLabel)findByName("movieDescriptionLabel", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.components.SpanLabel findQuestionArea(Component root) {
        return (com.codename1.components.SpanLabel)findByName("QuestionArea", root);
    }

    public com.codename1.components.SpanLabel findQuestionArea() {
        com.codename1.components.SpanLabel cmp = (com.codename1.components.SpanLabel)findByName("QuestionArea", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.components.SpanLabel)findByName("QuestionArea", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.components.WebBrowser findWebBrowser(Component root) {
        return (com.codename1.components.WebBrowser)findByName("WebBrowser", root);
    }

    public com.codename1.components.WebBrowser findWebBrowser() {
        com.codename1.components.WebBrowser cmp = (com.codename1.components.WebBrowser)findByName("WebBrowser", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.components.WebBrowser)findByName("WebBrowser", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Label findGenreLabel(Component root) {
        return (com.codename1.ui.Label)findByName("genreLabel", root);
    }

    public com.codename1.ui.Label findGenreLabel() {
        com.codename1.ui.Label cmp = (com.codename1.ui.Label)findByName("genreLabel", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Label)findByName("genreLabel", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Button findNewsButton(Component root) {
        return (com.codename1.ui.Button)findByName("NewsButton", root);
    }

    public com.codename1.ui.Button findNewsButton() {
        com.codename1.ui.Button cmp = (com.codename1.ui.Button)findByName("NewsButton", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Button)findByName("NewsButton", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.TextArea findMessageTextArea(Component root) {
        return (com.codename1.ui.TextArea)findByName("MessageTextArea", root);
    }

    public com.codename1.ui.TextArea findMessageTextArea() {
        com.codename1.ui.TextArea cmp = (com.codename1.ui.TextArea)findByName("MessageTextArea", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.TextArea)findByName("MessageTextArea", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Label findRatingLabel(Component root) {
        return (com.codename1.ui.Label)findByName("ratingLabel", root);
    }

    public com.codename1.ui.Label findRatingLabel() {
        com.codename1.ui.Label cmp = (com.codename1.ui.Label)findByName("ratingLabel", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Label)findByName("ratingLabel", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Label findMessageLabel(Component root) {
        return (com.codename1.ui.Label)findByName("MessageLabel", root);
    }

    public com.codename1.ui.Label findMessageLabel() {
        com.codename1.ui.Label cmp = (com.codename1.ui.Label)findByName("MessageLabel", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Label)findByName("MessageLabel", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.list.MultiList findSecondNewsMultiList(Component root) {
        return (com.codename1.ui.list.MultiList)findByName("SecondNewsMultiList", root);
    }

    public com.codename1.ui.list.MultiList findSecondNewsMultiList() {
        com.codename1.ui.list.MultiList cmp = (com.codename1.ui.list.MultiList)findByName("SecondNewsMultiList", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.list.MultiList)findByName("SecondNewsMultiList", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Label findTitleLabel(Component root) {
        return (com.codename1.ui.Label)findByName("titleLabel", root);
    }

    public com.codename1.ui.Label findTitleLabel() {
        com.codename1.ui.Label cmp = (com.codename1.ui.Label)findByName("titleLabel", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Label)findByName("titleLabel", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Label findMovieRatingLabel(Component root) {
        return (com.codename1.ui.Label)findByName("movieRatingLabel", root);
    }

    public com.codename1.ui.Label findMovieRatingLabel() {
        com.codename1.ui.Label cmp = (com.codename1.ui.Label)findByName("movieRatingLabel", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Label)findByName("movieRatingLabel", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Label findFirstQuestionLabel(Component root) {
        return (com.codename1.ui.Label)findByName("FirstQuestionLabel", root);
    }

    public com.codename1.ui.Label findFirstQuestionLabel() {
        com.codename1.ui.Label cmp = (com.codename1.ui.Label)findByName("FirstQuestionLabel", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Label)findByName("FirstQuestionLabel", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Label findTitleNewsLabel(Component root) {
        return (com.codename1.ui.Label)findByName("TitleNewsLabel", root);
    }

    public com.codename1.ui.Label findTitleNewsLabel() {
        com.codename1.ui.Label cmp = (com.codename1.ui.Label)findByName("TitleNewsLabel", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Label)findByName("TitleNewsLabel", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Label findTrueLabel(Component root) {
        return (com.codename1.ui.Label)findByName("TrueLabel", root);
    }

    public com.codename1.ui.Label findTrueLabel() {
        com.codename1.ui.Label cmp = (com.codename1.ui.Label)findByName("TrueLabel", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Label)findByName("TrueLabel", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.components.SpanLabel findMovieTitleLabel(Component root) {
        return (com.codename1.components.SpanLabel)findByName("movieTitleLabel", root);
    }

    public com.codename1.components.SpanLabel findMovieTitleLabel() {
        com.codename1.components.SpanLabel cmp = (com.codename1.components.SpanLabel)findByName("movieTitleLabel", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.components.SpanLabel)findByName("movieTitleLabel", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Button findHelpButton(Component root) {
        return (com.codename1.ui.Button)findByName("HelpButton", root);
    }

    public com.codename1.ui.Button findHelpButton() {
        com.codename1.ui.Button cmp = (com.codename1.ui.Button)findByName("HelpButton", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Button)findByName("HelpButton", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Button findGreenButton(Component root) {
        return (com.codename1.ui.Button)findByName("GreenButton", root);
    }

    public com.codename1.ui.Button findGreenButton() {
        com.codename1.ui.Button cmp = (com.codename1.ui.Button)findByName("GreenButton", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Button)findByName("GreenButton", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Label findMovieGenreLabel(Component root) {
        return (com.codename1.ui.Label)findByName("movieGenreLabel", root);
    }

    public com.codename1.ui.Label findMovieGenreLabel() {
        com.codename1.ui.Label cmp = (com.codename1.ui.Label)findByName("movieGenreLabel", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Label)findByName("movieGenreLabel", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Container findContainerSouth(Component root) {
        return (com.codename1.ui.Container)findByName("ContainerSouth", root);
    }

    public com.codename1.ui.Container findContainerSouth() {
        com.codename1.ui.Container cmp = (com.codename1.ui.Container)findByName("ContainerSouth", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Container)findByName("ContainerSouth", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Button findMovieImageButton(Component root) {
        return (com.codename1.ui.Button)findByName("movieImageButton", root);
    }

    public com.codename1.ui.Button findMovieImageButton() {
        com.codename1.ui.Button cmp = (com.codename1.ui.Button)findByName("movieImageButton", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Button)findByName("movieImageButton", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Label findSubjectLabel(Component root) {
        return (com.codename1.ui.Label)findByName("SubjectLabel", root);
    }

    public com.codename1.ui.Label findSubjectLabel() {
        com.codename1.ui.Label cmp = (com.codename1.ui.Label)findByName("SubjectLabel", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Label)findByName("SubjectLabel", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Button findRedButton(Component root) {
        return (com.codename1.ui.Button)findByName("RedButton", root);
    }

    public com.codename1.ui.Button findRedButton() {
        com.codename1.ui.Button cmp = (com.codename1.ui.Button)findByName("RedButton", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Button)findByName("RedButton", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Button findContactUsButton(Component root) {
        return (com.codename1.ui.Button)findByName("ContactUsButton", root);
    }

    public com.codename1.ui.Button findContactUsButton() {
        com.codename1.ui.Button cmp = (com.codename1.ui.Button)findByName("ContactUsButton", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Button)findByName("ContactUsButton", aboutToShowThisContainer);
        }
        return cmp;
    }

    public com.codename1.ui.Label findDescriptionLabel(Component root) {
        return (com.codename1.ui.Label)findByName("descriptionLabel", root);
    }

    public com.codename1.ui.Label findDescriptionLabel() {
        com.codename1.ui.Label cmp = (com.codename1.ui.Label)findByName("descriptionLabel", Display.getInstance().getCurrent());
        if(cmp == null && aboutToShowThisContainer != null) {
            cmp = (com.codename1.ui.Label)findByName("descriptionLabel", aboutToShowThisContainer);
        }
        return cmp;
    }

    public static final int COMMAND_FAQCommand9 = 9;
    public static final int COMMAND_FAQCommand8 = 8;
    public static final int COMMAND_QuestionsCommand7 = 7;
    public static final int COMMAND_FAQCommand6 = 6;
    public static final int COMMAND_MainCommand5 = 5;
    public static final int COMMAND_MainCommand4 = 4;

    protected boolean onFAQCommand9() {
        return false;
    }

    protected boolean onFAQCommand8() {
        return false;
    }

    protected boolean onQuestionsCommand7() {
        return false;
    }

    protected boolean onFAQCommand6() {
        return false;
    }

    protected boolean onMainCommand5() {
        return false;
    }

    protected boolean onMainCommand4() {
        return false;
    }

    protected void processCommand(ActionEvent ev, Command cmd) {
        switch(cmd.getId()) {
            case COMMAND_FAQCommand9:
                if(onFAQCommand9()) {
                    ev.consume();
                    return;
                }
                break;

            case COMMAND_FAQCommand8:
                if(onFAQCommand8()) {
                    ev.consume();
                    return;
                }
                break;

            case COMMAND_QuestionsCommand7:
                if(onQuestionsCommand7()) {
                    ev.consume();
                    return;
                }
                break;

            case COMMAND_FAQCommand6:
                if(onFAQCommand6()) {
                    ev.consume();
                    return;
                }
                break;

            case COMMAND_MainCommand5:
                if(onMainCommand5()) {
                    ev.consume();
                    return;
                }
                break;

            case COMMAND_MainCommand4:
                if(onMainCommand4()) {
                    ev.consume();
                    return;
                }
                break;

        }
        if(ev.getComponent() != null) {
            handleComponentAction(ev.getComponent(), ev);
        }
    }

    protected void exitForm(Form f) {
        if("Questions".equals(f.getName())) {
            exitQuestions(f);
            aboutToShowThisContainer = null;
            return;
        }

        if("ContactUs".equals(f.getName())) {
            exitContactUs(f);
            aboutToShowThisContainer = null;
            return;
        }

        if("MoviePoster".equals(f.getName())) {
            exitMoviePoster(f);
            aboutToShowThisContainer = null;
            return;
        }

        if("MoviesList".equals(f.getName())) {
            exitMoviesList(f);
            aboutToShowThisContainer = null;
            return;
        }

        if("MovieDetails".equals(f.getName())) {
            exitMovieDetails(f);
            aboutToShowThisContainer = null;
            return;
        }

        if("FAQNews".equals(f.getName())) {
            exitFAQNews(f);
            aboutToShowThisContainer = null;
            return;
        }

        if("FAQQuestions".equals(f.getName())) {
            exitFAQQuestions(f);
            aboutToShowThisContainer = null;
            return;
        }

        if("MovieTrailer".equals(f.getName())) {
            exitMovieTrailer(f);
            aboutToShowThisContainer = null;
            return;
        }

        if("FAQ".equals(f.getName())) {
            exitFAQ(f);
            aboutToShowThisContainer = null;
            return;
        }

        if("Main".equals(f.getName())) {
            exitMain(f);
            aboutToShowThisContainer = null;
            return;
        }

            return;
    }


    protected void exitQuestions(Form f) {
    }


    protected void exitContactUs(Form f) {
    }


    protected void exitMoviePoster(Form f) {
    }


    protected void exitMoviesList(Form f) {
    }


    protected void exitMovieDetails(Form f) {
    }


    protected void exitFAQNews(Form f) {
    }


    protected void exitFAQQuestions(Form f) {
    }


    protected void exitMovieTrailer(Form f) {
    }


    protected void exitFAQ(Form f) {
    }


    protected void exitMain(Form f) {
    }

    protected void beforeShow(Form f) {
    aboutToShowThisContainer = f;
        if("Questions".equals(f.getName())) {
            beforeQuestions(f);
            aboutToShowThisContainer = null;
            return;
        }

        if("ContactUs".equals(f.getName())) {
            beforeContactUs(f);
            aboutToShowThisContainer = null;
            return;
        }

        if("MoviePoster".equals(f.getName())) {
            beforeMoviePoster(f);
            aboutToShowThisContainer = null;
            return;
        }

        if("MoviesList".equals(f.getName())) {
            beforeMoviesList(f);
            aboutToShowThisContainer = null;
            return;
        }

        if("MovieDetails".equals(f.getName())) {
            beforeMovieDetails(f);
            aboutToShowThisContainer = null;
            return;
        }

        if("FAQNews".equals(f.getName())) {
            beforeFAQNews(f);
            aboutToShowThisContainer = null;
            return;
        }

        if("FAQQuestions".equals(f.getName())) {
            beforeFAQQuestions(f);
            aboutToShowThisContainer = null;
            return;
        }

        if("MovieTrailer".equals(f.getName())) {
            beforeMovieTrailer(f);
            aboutToShowThisContainer = null;
            return;
        }

        if("FAQ".equals(f.getName())) {
            beforeFAQ(f);
            aboutToShowThisContainer = null;
            return;
        }

        if("Main".equals(f.getName())) {
            beforeMain(f);
            aboutToShowThisContainer = null;
            return;
        }

            return;
    }


    protected void beforeQuestions(Form f) {
    }


    protected void beforeContactUs(Form f) {
    }


    protected void beforeMoviePoster(Form f) {
    }


    protected void beforeMoviesList(Form f) {
    }


    protected void beforeMovieDetails(Form f) {
    }


    protected void beforeFAQNews(Form f) {
    }


    protected void beforeFAQQuestions(Form f) {
    }


    protected void beforeMovieTrailer(Form f) {
    }


    protected void beforeFAQ(Form f) {
    }


    protected void beforeMain(Form f) {
    }

    protected void beforeShowContainer(Container c) {
        aboutToShowThisContainer = c;
        if("Questions".equals(c.getName())) {
            beforeContainerQuestions(c);
            aboutToShowThisContainer = null;
            return;
        }

        if("ContactUs".equals(c.getName())) {
            beforeContainerContactUs(c);
            aboutToShowThisContainer = null;
            return;
        }

        if("MoviePoster".equals(c.getName())) {
            beforeContainerMoviePoster(c);
            aboutToShowThisContainer = null;
            return;
        }

        if("MoviesList".equals(c.getName())) {
            beforeContainerMoviesList(c);
            aboutToShowThisContainer = null;
            return;
        }

        if("MovieDetails".equals(c.getName())) {
            beforeContainerMovieDetails(c);
            aboutToShowThisContainer = null;
            return;
        }

        if("FAQNews".equals(c.getName())) {
            beforeContainerFAQNews(c);
            aboutToShowThisContainer = null;
            return;
        }

        if("FAQQuestions".equals(c.getName())) {
            beforeContainerFAQQuestions(c);
            aboutToShowThisContainer = null;
            return;
        }

        if("MovieTrailer".equals(c.getName())) {
            beforeContainerMovieTrailer(c);
            aboutToShowThisContainer = null;
            return;
        }

        if("FAQ".equals(c.getName())) {
            beforeContainerFAQ(c);
            aboutToShowThisContainer = null;
            return;
        }

        if("Main".equals(c.getName())) {
            beforeContainerMain(c);
            aboutToShowThisContainer = null;
            return;
        }

            return;
    }


    protected void beforeContainerQuestions(Container c) {
    }


    protected void beforeContainerContactUs(Container c) {
    }


    protected void beforeContainerMoviePoster(Container c) {
    }


    protected void beforeContainerMoviesList(Container c) {
    }


    protected void beforeContainerMovieDetails(Container c) {
    }


    protected void beforeContainerFAQNews(Container c) {
    }


    protected void beforeContainerFAQQuestions(Container c) {
    }


    protected void beforeContainerMovieTrailer(Container c) {
    }


    protected void beforeContainerFAQ(Container c) {
    }


    protected void beforeContainerMain(Container c) {
    }

    protected void postShow(Form f) {
        if("Questions".equals(f.getName())) {
            postQuestions(f);
            aboutToShowThisContainer = null;
            return;
        }

        if("ContactUs".equals(f.getName())) {
            postContactUs(f);
            aboutToShowThisContainer = null;
            return;
        }

        if("MoviePoster".equals(f.getName())) {
            postMoviePoster(f);
            aboutToShowThisContainer = null;
            return;
        }

        if("MoviesList".equals(f.getName())) {
            postMoviesList(f);
            aboutToShowThisContainer = null;
            return;
        }

        if("MovieDetails".equals(f.getName())) {
            postMovieDetails(f);
            aboutToShowThisContainer = null;
            return;
        }

        if("FAQNews".equals(f.getName())) {
            postFAQNews(f);
            aboutToShowThisContainer = null;
            return;
        }

        if("FAQQuestions".equals(f.getName())) {
            postFAQQuestions(f);
            aboutToShowThisContainer = null;
            return;
        }

        if("MovieTrailer".equals(f.getName())) {
            postMovieTrailer(f);
            aboutToShowThisContainer = null;
            return;
        }

        if("FAQ".equals(f.getName())) {
            postFAQ(f);
            aboutToShowThisContainer = null;
            return;
        }

        if("Main".equals(f.getName())) {
            postMain(f);
            aboutToShowThisContainer = null;
            return;
        }

            return;
    }


    protected void postQuestions(Form f) {
    }


    protected void postContactUs(Form f) {
    }


    protected void postMoviePoster(Form f) {
    }


    protected void postMoviesList(Form f) {
    }


    protected void postMovieDetails(Form f) {
    }


    protected void postFAQNews(Form f) {
    }


    protected void postFAQQuestions(Form f) {
    }


    protected void postMovieTrailer(Form f) {
    }


    protected void postFAQ(Form f) {
    }


    protected void postMain(Form f) {
    }

    protected void postShowContainer(Container c) {
        if("Questions".equals(c.getName())) {
            postContainerQuestions(c);
            aboutToShowThisContainer = null;
            return;
        }

        if("ContactUs".equals(c.getName())) {
            postContainerContactUs(c);
            aboutToShowThisContainer = null;
            return;
        }

        if("MoviePoster".equals(c.getName())) {
            postContainerMoviePoster(c);
            aboutToShowThisContainer = null;
            return;
        }

        if("MoviesList".equals(c.getName())) {
            postContainerMoviesList(c);
            aboutToShowThisContainer = null;
            return;
        }

        if("MovieDetails".equals(c.getName())) {
            postContainerMovieDetails(c);
            aboutToShowThisContainer = null;
            return;
        }

        if("FAQNews".equals(c.getName())) {
            postContainerFAQNews(c);
            aboutToShowThisContainer = null;
            return;
        }

        if("FAQQuestions".equals(c.getName())) {
            postContainerFAQQuestions(c);
            aboutToShowThisContainer = null;
            return;
        }

        if("MovieTrailer".equals(c.getName())) {
            postContainerMovieTrailer(c);
            aboutToShowThisContainer = null;
            return;
        }

        if("FAQ".equals(c.getName())) {
            postContainerFAQ(c);
            aboutToShowThisContainer = null;
            return;
        }

        if("Main".equals(c.getName())) {
            postContainerMain(c);
            aboutToShowThisContainer = null;
            return;
        }

            return;
    }


    protected void postContainerQuestions(Container c) {
    }


    protected void postContainerContactUs(Container c) {
    }


    protected void postContainerMoviePoster(Container c) {
    }


    protected void postContainerMoviesList(Container c) {
    }


    protected void postContainerMovieDetails(Container c) {
    }


    protected void postContainerFAQNews(Container c) {
    }


    protected void postContainerFAQQuestions(Container c) {
    }


    protected void postContainerMovieTrailer(Container c) {
    }


    protected void postContainerFAQ(Container c) {
    }


    protected void postContainerMain(Container c) {
    }

    protected void onCreateRoot(String rootName) {
        if("Questions".equals(rootName)) {
            onCreateQuestions();
            aboutToShowThisContainer = null;
            return;
        }

        if("ContactUs".equals(rootName)) {
            onCreateContactUs();
            aboutToShowThisContainer = null;
            return;
        }

        if("MoviePoster".equals(rootName)) {
            onCreateMoviePoster();
            aboutToShowThisContainer = null;
            return;
        }

        if("MoviesList".equals(rootName)) {
            onCreateMoviesList();
            aboutToShowThisContainer = null;
            return;
        }

        if("MovieDetails".equals(rootName)) {
            onCreateMovieDetails();
            aboutToShowThisContainer = null;
            return;
        }

        if("FAQNews".equals(rootName)) {
            onCreateFAQNews();
            aboutToShowThisContainer = null;
            return;
        }

        if("FAQQuestions".equals(rootName)) {
            onCreateFAQQuestions();
            aboutToShowThisContainer = null;
            return;
        }

        if("MovieTrailer".equals(rootName)) {
            onCreateMovieTrailer();
            aboutToShowThisContainer = null;
            return;
        }

        if("FAQ".equals(rootName)) {
            onCreateFAQ();
            aboutToShowThisContainer = null;
            return;
        }

        if("Main".equals(rootName)) {
            onCreateMain();
            aboutToShowThisContainer = null;
            return;
        }

            return;
    }


    protected void onCreateQuestions() {
    }


    protected void onCreateContactUs() {
    }


    protected void onCreateMoviePoster() {
    }


    protected void onCreateMoviesList() {
    }


    protected void onCreateMovieDetails() {
    }


    protected void onCreateFAQNews() {
    }


    protected void onCreateFAQQuestions() {
    }


    protected void onCreateMovieTrailer() {
    }


    protected void onCreateFAQ() {
    }


    protected void onCreateMain() {
    }

    protected Hashtable getFormState(Form f) {
        Hashtable h = super.getFormState(f);
        if("Questions".equals(f.getName())) {
            getStateQuestions(f, h);
            aboutToShowThisContainer = null;
            return h;
        }

        if("ContactUs".equals(f.getName())) {
            getStateContactUs(f, h);
            aboutToShowThisContainer = null;
            return h;
        }

        if("MoviePoster".equals(f.getName())) {
            getStateMoviePoster(f, h);
            aboutToShowThisContainer = null;
            return h;
        }

        if("MoviesList".equals(f.getName())) {
            getStateMoviesList(f, h);
            aboutToShowThisContainer = null;
            return h;
        }

        if("MovieDetails".equals(f.getName())) {
            getStateMovieDetails(f, h);
            aboutToShowThisContainer = null;
            return h;
        }

        if("FAQNews".equals(f.getName())) {
            getStateFAQNews(f, h);
            aboutToShowThisContainer = null;
            return h;
        }

        if("FAQQuestions".equals(f.getName())) {
            getStateFAQQuestions(f, h);
            aboutToShowThisContainer = null;
            return h;
        }

        if("MovieTrailer".equals(f.getName())) {
            getStateMovieTrailer(f, h);
            aboutToShowThisContainer = null;
            return h;
        }

        if("FAQ".equals(f.getName())) {
            getStateFAQ(f, h);
            aboutToShowThisContainer = null;
            return h;
        }

        if("Main".equals(f.getName())) {
            getStateMain(f, h);
            aboutToShowThisContainer = null;
            return h;
        }

            return h;
    }


    protected void getStateQuestions(Form f, Hashtable h) {
    }


    protected void getStateContactUs(Form f, Hashtable h) {
    }


    protected void getStateMoviePoster(Form f, Hashtable h) {
    }


    protected void getStateMoviesList(Form f, Hashtable h) {
    }


    protected void getStateMovieDetails(Form f, Hashtable h) {
    }


    protected void getStateFAQNews(Form f, Hashtable h) {
    }


    protected void getStateFAQQuestions(Form f, Hashtable h) {
    }


    protected void getStateMovieTrailer(Form f, Hashtable h) {
    }


    protected void getStateFAQ(Form f, Hashtable h) {
    }


    protected void getStateMain(Form f, Hashtable h) {
    }

    protected void setFormState(Form f, Hashtable state) {
        super.setFormState(f, state);
        if("Questions".equals(f.getName())) {
            setStateQuestions(f, state);
            aboutToShowThisContainer = null;
            return;
        }

        if("ContactUs".equals(f.getName())) {
            setStateContactUs(f, state);
            aboutToShowThisContainer = null;
            return;
        }

        if("MoviePoster".equals(f.getName())) {
            setStateMoviePoster(f, state);
            aboutToShowThisContainer = null;
            return;
        }

        if("MoviesList".equals(f.getName())) {
            setStateMoviesList(f, state);
            aboutToShowThisContainer = null;
            return;
        }

        if("MovieDetails".equals(f.getName())) {
            setStateMovieDetails(f, state);
            aboutToShowThisContainer = null;
            return;
        }

        if("FAQNews".equals(f.getName())) {
            setStateFAQNews(f, state);
            aboutToShowThisContainer = null;
            return;
        }

        if("FAQQuestions".equals(f.getName())) {
            setStateFAQQuestions(f, state);
            aboutToShowThisContainer = null;
            return;
        }

        if("MovieTrailer".equals(f.getName())) {
            setStateMovieTrailer(f, state);
            aboutToShowThisContainer = null;
            return;
        }

        if("FAQ".equals(f.getName())) {
            setStateFAQ(f, state);
            aboutToShowThisContainer = null;
            return;
        }

        if("Main".equals(f.getName())) {
            setStateMain(f, state);
            aboutToShowThisContainer = null;
            return;
        }

            return;
    }


    protected void setStateQuestions(Form f, Hashtable state) {
    }


    protected void setStateContactUs(Form f, Hashtable state) {
    }


    protected void setStateMoviePoster(Form f, Hashtable state) {
    }


    protected void setStateMoviesList(Form f, Hashtable state) {
    }


    protected void setStateMovieDetails(Form f, Hashtable state) {
    }


    protected void setStateFAQNews(Form f, Hashtable state) {
    }


    protected void setStateFAQQuestions(Form f, Hashtable state) {
    }


    protected void setStateMovieTrailer(Form f, Hashtable state) {
    }


    protected void setStateFAQ(Form f, Hashtable state) {
    }


    protected void setStateMain(Form f, Hashtable state) {
    }

    protected boolean setListModel(List cmp) {
        String listName = cmp.getName();
        if("NewsMultiList".equals(listName)) {
            return initListModelNewsMultiList(cmp);
        }
        if("SecondNewsMultiList".equals(listName)) {
            return initListModelSecondNewsMultiList(cmp);
        }
        return super.setListModel(cmp);
    }

    protected boolean initListModelNewsMultiList(List cmp) {
        return false;
    }

    protected boolean initListModelSecondNewsMultiList(List cmp) {
        return false;
    }

    protected void handleComponentAction(Component c, ActionEvent event) {
        Container rootContainerAncestor = getRootAncestor(c);
        if(rootContainerAncestor == null) return;
        String rootContainerName = rootContainerAncestor.getName();
        Container leadParentContainer = c.getParent().getLeadParent();
        if(leadParentContainer != null && leadParentContainer.getClass() != Container.class) {
            c = c.getParent().getLeadParent();
        }
        if(rootContainerName == null) return;
        if(rootContainerName.equals("Questions")) {
            if("RedButton".equals(c.getName())) {
                onQuestions_RedButtonAction(c, event);
                return;
            }
            if("GreenButton".equals(c.getName())) {
                onQuestions_GreenButtonAction(c, event);
                return;
            }
        }
        if(rootContainerName.equals("ContactUs")) {
            if("SubjectTextField".equals(c.getName())) {
                onContactUs_SubjectTextFieldAction(c, event);
                return;
            }
            if("MessageTextArea".equals(c.getName())) {
                onContactUs_MessageTextAreaAction(c, event);
                return;
            }
            if("Button".equals(c.getName())) {
                onContactUs_ButtonAction(c, event);
                return;
            }
        }
        if(rootContainerName.equals("MovieDetails")) {
            if("movieImageButton".equals(c.getName())) {
                onMovieDetails_MovieImageButtonAction(c, event);
                return;
            }
            if("trailerButton".equals(c.getName())) {
                onMovieDetails_TrailerButtonAction(c, event);
                return;
            }
        }
        if(rootContainerName.equals("FAQNews")) {
            if("NewsMultiList".equals(c.getName())) {
                onFAQNews_NewsMultiListAction(c, event);
                return;
            }
            if("SecondNewsMultiList".equals(c.getName())) {
                onFAQNews_SecondNewsMultiListAction(c, event);
                return;
            }
        }
        if(rootContainerName.equals("FAQ")) {
            if("QuestionsButton".equals(c.getName())) {
                onFAQ_QuestionsButtonAction(c, event);
                return;
            }
            if("NewsButton".equals(c.getName())) {
                onFAQ_NewsButtonAction(c, event);
                return;
            }
            if("ContactUsButton".equals(c.getName())) {
                onFAQ_ContactUsButtonAction(c, event);
                return;
            }
        }
        if(rootContainerName.equals("Main")) {
            if("HelpButton".equals(c.getName())) {
                onMain_HelpButtonAction(c, event);
                return;
            }
            if("BeginButton".equals(c.getName())) {
                onMain_BeginButtonAction(c, event);
                return;
            }
        }
    }

      protected void onQuestions_RedButtonAction(Component c, ActionEvent event) {
      }

      protected void onQuestions_GreenButtonAction(Component c, ActionEvent event) {
      }

      protected void onContactUs_SubjectTextFieldAction(Component c, ActionEvent event) {
      }

      protected void onContactUs_MessageTextAreaAction(Component c, ActionEvent event) {
      }

      protected void onContactUs_ButtonAction(Component c, ActionEvent event) {
      }

      protected void onMovieDetails_MovieImageButtonAction(Component c, ActionEvent event) {
      }

      protected void onMovieDetails_TrailerButtonAction(Component c, ActionEvent event) {
      }

      protected void onFAQNews_NewsMultiListAction(Component c, ActionEvent event) {
      }

      protected void onFAQNews_SecondNewsMultiListAction(Component c, ActionEvent event) {
      }

      protected void onFAQ_QuestionsButtonAction(Component c, ActionEvent event) {
      }

      protected void onFAQ_NewsButtonAction(Component c, ActionEvent event) {
      }

      protected void onFAQ_ContactUsButtonAction(Component c, ActionEvent event) {
      }

      protected void onMain_HelpButtonAction(Component c, ActionEvent event) {
      }

      protected void onMain_BeginButtonAction(Component c, ActionEvent event) {
      }

}
