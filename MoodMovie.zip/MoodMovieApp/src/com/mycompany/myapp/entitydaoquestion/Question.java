/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.myapp.entitydaoquestion;

/**
 *
 * @author eric3
 */
public class Question {
    private int id;
    private String question;
    private boolean isLiked;
    private boolean isStillValid;
    
    private String genreDeletedWhenLiked;
    private String genreDeletedWhenUnliked;
    
    
    
    
    public int getId(){ return id;}
    public void setId(int id){ this.id = id;}
    
    public String getQuestion(){ return question;}
    public void setQuestion(String question){ this.question = question;}
    
    public boolean getIsLiked(){ return isLiked;}
    public void setIsLiked(boolean isLiked){ this.isLiked = isLiked;}
    
    public boolean getIsStillValid(){ return isStillValid;}
    public void setIsStillValid(boolean isStillValid){ this.isStillValid = isStillValid;}
    
    public String getGenreDeletedWhenLiked(){ return genreDeletedWhenLiked;}
    public void setgenreWhenLiked(String genreDeletedWhenLiked){ this.genreDeletedWhenLiked = genreDeletedWhenLiked;}
    
    public String getGenreDeletedWhenUnLiked(){ return genreDeletedWhenUnliked;}
    public void setgenreWhenUnliked(String genreDeletedWhenUnliked){ this.genreDeletedWhenUnliked = genreDeletedWhenUnliked;}
}
