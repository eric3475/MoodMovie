/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.myapp.entitydaoquestion;

import ca.weblite.codename1.db.DAO;
import ca.weblite.codename1.db.DAOProvider;
import java.io.IOException;
import java.util.Map;

/**
 *
 * @author eric3
 */
public class QuestionDAO extends DAO<Question> {

    public QuestionDAO(DAOProvider provider) throws IOException{
        super("question", provider);
        // "people" is the table name that this DAO is used for.
    }


    @Override
    public void map(Question object, Map values){
        values.put("id", object.getId());
        values.put("isLiked", object.getIsLiked());
        values.put("question", object.getQuestion());
        values.put("genreDeletedWhenLiked", object.getGenreDeletedWhenLiked());
        values.put("genreDeletedWhenUnliked", object.getGenreDeletedWhenUnLiked());
        values.put("isStillValid", object.getIsStillValid());
    }
    
    @Override
    public void unmap(Question object, Map values){
        object.setId((int) values.get("id"));
        object.setIsLiked((boolean) values.get("isLiked"));
        object.setQuestion((String) values.get("question"));
        object.setgenreWhenLiked((String) values.get("genreDeletedWhenLiked"));
        object.setgenreWhenUnliked((String) values.get("genreDeletedWhenUnliked"));
        object.setIsStillValid((boolean) values.get("isStillValid"));
    }

    @Override
    public Question newObject(){ return new Question();}

    @Override
    public long getId(Question t) {
        return (long) t.getId(); 
    }


}
    

