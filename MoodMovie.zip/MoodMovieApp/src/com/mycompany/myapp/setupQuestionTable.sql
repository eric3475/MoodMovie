CREATE TABLE question (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    question VARCHAR,
    is_likqed BOOLEAN,
    is_still_valid BOOLEAN,
    genre_deleted_when_liked VARCHAR,
    genre_deleted_when_unliked VARCHAR
);
